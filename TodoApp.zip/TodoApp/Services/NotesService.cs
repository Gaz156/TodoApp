﻿using Microsoft.EntityFrameworkCore;
using TodoApp.Data;
using TodoApp.Models;

namespace TodoApp.Services
{
    public class NotesService : INotesService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<NotesService> _logger;

        public NotesService(ApplicationDbContext context, ILogger<NotesService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<Note>> GetUserNotesAsync(int userId)
        {
            try
            {
                return await _context.Notes
                    .Where(n => n.UserId == userId)
                    .OrderByDescending(n => n.ModifiedDate)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting notes for user {userId}");
                throw;
            }
        }

        public async Task<Note> GetNoteByIdAsync(int noteId, int userId)
        {
            try
            {
                return await _context.Notes
                    .FirstOrDefaultAsync(n => n.NoteId == noteId && n.UserId == userId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting note {noteId} for user {userId}");
                throw;
            }
        }

        public async Task<Note> CreateNoteAsync(Note note)
        {
            try
            {
                note.CreatedDate = DateTime.UtcNow;
                note.ModifiedDate = DateTime.UtcNow;

                _context.Notes.Add(note);
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Note created: ID {note.NoteId}, User {note.UserId}, Title: {note.Title}");
                return note;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error creating note for user {note.UserId}");
                throw;
            }
        }

        public async Task UpdateNoteAsync(Note note)
        {
            try
            {
                note.ModifiedDate = DateTime.UtcNow;
                _context.Notes.Update(note);
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Note updated: ID {note.NoteId}, User {note.UserId}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating note {note.NoteId} for user {note.UserId}");
                throw;
            }
        }

        public async Task DeleteNoteAsync(int noteId, int userId)
        {
            try
            {
                var note = await GetNoteByIdAsync(noteId, userId);
                if (note != null)
                {
                    _context.Notes.Remove(note);
                    await _context.SaveChangesAsync();

                    _logger.LogInformation($"Note deleted: ID {noteId}, User {userId}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting note {noteId} for user {userId}");
                throw;
            }
        }

        public async Task<bool> NoteExistsAsync(int noteId, int userId)
        {
            return await _context.Notes
                .AnyAsync(n => n.NoteId == noteId && n.UserId == userId);
        }
    }
}