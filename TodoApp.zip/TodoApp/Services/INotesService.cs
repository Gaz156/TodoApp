﻿using TodoApp.Models;

namespace TodoApp.Services
{
    public interface INotesService
    {
        Task<IEnumerable<Note>> GetUserNotesAsync(int userId);
        Task<Note> GetNoteByIdAsync(int noteId, int userId);
        Task<Note> CreateNoteAsync(Note note);
        Task UpdateNoteAsync(Note note);
        Task DeleteNoteAsync(int noteId, int userId);
    }
}