﻿using TodoApp.Models;
using TodoApp.Models.ViewModels;

namespace TodoApp.Services
{
    public interface IAuthService
    {
        Task<User> AuthenticateAsync(string usernameOrEmail, string password);
        Task<User> RegisterAsync(RegisterViewModel model);
        string HashPassword(string password);
        bool VerifyPassword(string password, string hashedPassword);
    }
}